﻿

public class AzureConfig
{
    public string EndPoint { get; set; }

    public string SubscriptionKey { get; set; }

}